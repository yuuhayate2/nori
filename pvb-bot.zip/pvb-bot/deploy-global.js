const { REST, Routes } = require("discord.js");
require("dotenv").config();
const fs = require("fs");

const commands = [];
const files = fs.readdirSync("./commands").filter(f => f.endsWith(".js"));

for (const f of files) {
  const c = require(`./commands/${f}`);
  commands.push(c.data.toJSON());
}

const rest = new REST({ version: "10" }).setToken(process.env.TOKEN);

(async () => {
  try {
    console.log("🔄 Deploying global commands...");
    await rest.put(
      Routes.applicationCommands(process.env.CLIENT_ID),
      { body: commands }
    );
    console.log("✅ Global slash commands deployed.");
  } catch (e) {
    console.error(e);
  }
})();
