const { REST, Routes } = require("discord.js");
require("dotenv").config();
const fs = require("fs");

const commands = [];
const files = fs.readdirSync("./commands").filter(f => f.endsWith(".js"));

for (const f of files) {
  const c = require(`./commands/${f}`);
  commands.push(c.data.toJSON());
}

const rest = new REST({ version: "10" }).setToken(process.env.TOKEN);

(async () => {
  try {
    console.log("🔄 Deploying guild commands...");
    await rest.put(
      Routes.applicationGuildCommands(process.env.CLIENT_ID, process.env.GUILD_ID),
      { body: commands }
    );
    console.log("✅ Guild slash commands deployed.");
  } catch (e) {
    console.error(e);
  }
})();
